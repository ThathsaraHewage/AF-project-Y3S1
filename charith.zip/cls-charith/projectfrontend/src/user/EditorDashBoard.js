import React from 'react'
import Base from "../core/Base"
const EditorDashBoard = () => {
    return (
        <Base title="Editor DashBoard Page">
            <h1>This is a Editor Dash Board Page</h1>
        </Base>
    );
};

export default EditorDashBoard;