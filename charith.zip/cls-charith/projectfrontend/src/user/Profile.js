import React from 'react'
import Base from "../core/Base"
const Profile = () => {
    return (
        <Base title="Profile Page">
            <h1>This is a profile Page</h1>
        </Base>
    );
};

export default Profile;
