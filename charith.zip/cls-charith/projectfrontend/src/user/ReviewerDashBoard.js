import React from 'react'
import Base from "../core/Base"
const ReviewerDashBoard = () => {
    return (
        <Base title="Reviewer DashBoard Page">
            <h1>This is a Reviewer DashBoard Page</h1>
        </Base>
    );
};

export default ReviewerDashBoard;