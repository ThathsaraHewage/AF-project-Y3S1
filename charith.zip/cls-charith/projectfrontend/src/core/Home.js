import React from "react";
import "../styles.css";
import Base from "./Base";

export default function Home() {
  return (
    <Base title="Home Page" description="Welcome to the T-Shirt store">
      <div className="row text-center">
          <h1 className="text-white">home</h1>
          <div className="row">
              {/* {products.map((product, index) => {
                  return(
                      <div key={index} className="col-4 mb-4">
                        <Card product={product}/>
                      </div>
                  )
              })} */}
          </div>
      </div>
    </Base>
  );
}
